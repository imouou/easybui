// 手机调试请自行去掉
// import VConsole from 'vconsole';

// const vConsole = new VConsole();

window.router = bui.router();

bui.ready(function(global) {
    
    // 初始化路由
    router.init({
        id: "#bui-router",
        progress: true,
        hash: true,
        indexModule:{
            template:"pages/login/index.html",
            script:"pages/login/index.js",
        },
        beforeLoad(e){
            let token = global.storage.get("token",0);
            // 如果不在登录页，且没有用户信息，则只能进入首页
            if( e.target.name !== "main" && !token){
                bui.load({
                    url:"main"
                })
                // 禁止进入其它页面
                return false;
            }
        }
    })

    // 绑定事件
    bind();

    // 事件类定义
    function bind() {
        // 绑定页面的所有按钮有href跳转
        bui.btn({ id: "#bui-router", handle: ".bui-btn" }).load();

        // 统一绑定页面所有的后退按钮
        $("#bui-router").on("click", ".btn-back", function(e) {
            // 支持后退多层,支持回调
            bui.back();
        })
    }
});loader.set("pages/article/article",{
							   template:function(){
					   return `<div class="bui-page bui-box-vertical">
    <header>
        <div class="bui-bar">
            <div class="bui-bar-left">
                <div class="bui-btn" onclick="bui.back();"><i class="icon-back"></i></div>
            </div>
            <div class="bui-bar-main">文章详情</div>
            <div class="bui-bar-right">
                <div class="bui-btn btn-share"><i class="icon-share"></i></div>
            </div>
        </div>
    </header>
    <main>
        <article class="bui-article" b-template="article.tpl(article.datas)">
            <!-- <h1>标题</h1>
            <div class="article-info bui-box">
                <span class="article-from">广州党支部</span>
                <div class="span1"> <i class="icon-time"> 2018-03-14</i></div>
                <i class="icon-comment"> 42</i>
                <i class="icon-eye"> 142</i>
            </div>
            <section>
                <p>11月1日，温江区检察院召开党组（扩大）会议，传达学习党的十九大精神，研究学习宣传贯彻工作。会议由党组书记、检察长钟磊主持，院领导、全体部门负责人参加。</p>

                <p><img src="http://www.easybui.com/demo/images/article-img.jpg" alt=""></p>

                <h3>小节标题</h3>
                <p id="section">会上首先传达学习了党的十九大精神以及省、市、区委常委（扩大）会议精神，省、市、区传达学习党的十九大精神大会精神和市院党组（扩大）会议精神。院领导结合检察工作实际，逐一谈学习十九大精神感想和体会。钟磊检察长结合自身检察工作实际，分享自己学习十九大精神感想和体会，并作讲话。</p>
            </section> -->
        </article>
    </main>
</div>`;
		 },
							   loaded:function(require, exports, module, global) {
    var params = bui.history.getParams(module.id);

    var bs = bui.store({
        el: `#${module.id}`,
        scope: "article",
        data: {
           datas: {},
        },
        methods: {
            bindShare(){

                var uiActionsheet = bui.actionsheet({
                    trigger: ".btn-share",
                    buttons: [{ name: "分享到微博", value: "weibo" }, { name: "朋友圈", value: "pyq" }],
                    callback: function(e) {
                        var val = $(e.target).attr("value");
                        if (val == "cancel") {
                            this.hide();
                        }
                    }
                })
            },
            getDetail(id){
                global.ajax({
                    url: `${module.path}article.json`,
                    data: {
                        id:id
                    }
                }).then((result)=>{

                    let datas = bui.array.get(result.data,id,"id");

                    this.datas = datas;
                },function(result,status){

                });
            }
        },
        templates: {
            tpl(data){
                let html = `<h1>${data.title}</h1>
                <div class="article-info bui-box">
                    <span class="article-from">互联网</span>
                    <div class="span1"> <i class="icon-time"> 2021-03-14</i></div>
                    <i class="icon-comment"> 42</i>
                    <i class="icon-eye"> 142</i>
                </div>
                <section>
                    <p><img src="${data.image}" alt=""></p>
                    ${data.content}
                </section>`
                return html;
            }
        },
        mounted: function(){

            this.getDetail(params.id);

            this.bindShare();
        }
    })

    
}});;loader.set("pages/components/slide/slide",{
							   template:function(){
					   return `<div class="bui-slide bui-slide-skin01"></div>`;
		 },
							   loaded:function(require, exports, module, global){

    var props = module.props;



    props.id = `#${module.id} .bui-slide`;

    props.height = props.height || 200;
    props.autopage = true;
    props.data = props.data || [{image: "http://easybui.com/demo/images/banner01.png"},{image: "http://easybui.com/demo/images/banner02.png"}];

    const uiSlide = bui.slide(props);

    return uiSlide;
}});;loader.set("main",{
							   template:function(){
					   return `<div id="loginpage" class="bui-page bui-box-vertical">
    <header>
       <div class="bui-bar">
        <div class="bui-bar-left">
        </div>
        <div class="bui-bar-main">登录页</div>
        <div class="bui-bar-right">
            <!-- 右边按钮 -->
        </div>
       </div>
    </header>
    <main>
        <ul class="bui-list">
            <li class="bui-btn bui-box clearactive">
                <label class="bui-label">帐号</label>
                <div class="span1">
                    <input type="text" class="bui-input" value="" placeholder="请输入账号" b-model="form.datas.username">
                </div>
            </li>
            <li class="bui-btn bui-box clearactive">
                <label class="bui-label">密码</label>
                <div class="span1">
                    <input type="password" class="bui-input" value="" placeholder="请输入密码" b-model="form.datas.password">
                </div>
            </li>
            <li class="bui-btn bui-box clearactive">
                <label class="bui-label">保存密码</label>
                <div class="span1">
                    <input type="checkbox" class="bui-checkbox" b-model="form.datas.save">
                </div>
            </li>
        </ul>
        <div class="container-y">
            <div class="bui-box-space">
                <div class="span1">
                    <div class="bui-btn round" href="pages/register/index.html">注册</div>
                </div>
                <div class="span1">
                    <div class="bui-btn round primary" b-click="form.submit">登录</div>
                </div>
            </div>
        </div>
    </main>
</div>
`;
		 },
							   loaded:function(requires, exports, module, global){

    const bs = bui.store({
        el: `#loginpage`,    // 容器下的行为指令
        scope: "form",      // 容器下的相同作用域指令
        data: {
            datas: {
                username:"",    // 账号名
                password:"",    // 密码
                save: false,     //保存密码
            },
        },
        methods: {
            checkForm(datas){

                for(let key in datas ){
                    let item = datas[key];
                    if( item === ""){
                        bui.hint(`${key}的内容不能为空`)
                        return false;
                    }
                }
                return true;
            },
            savePassword(val){

                if(this.$data.datas.save){
                    global.storage.set("userinfo",val);
                }else{
                    global.storage.remove("userinfo");
                }
            },
            submit(){

                let canSumit = this.checkForm(this.datas);
                if( !canSumit ){
                    return;
                }

                bui.ajax({
                    url: global.apiurl + "json/token.json",
                    data: this.datas // 表单收集到的内容
                }).then((res)=>{
                    bui.hint("登录成功")

                    this.savePassword(this.$data.datas);

                    global.storage.set("token",res.data);

                    bui.load({
                        url:"pages/main/main.html"
                    })
                })
            },
        },
        templates: {},
        mounted: function(){

            let uinfo = global.storage.get("userinfo",0);

            typeof uinfo ==="object" &&( this.datas = uinfo);
        }
    })

    return bs;
}});;loader.set("pages/login/page",{
							   template:function(){
					   return `<div id="loginpart" class="bui-page bui-box-vertical">
    <header>
       <div class="bui-bar">
        <div class="bui-bar-left">
            <a class="bui-btn" b-click="form.close"><i class="icon-back"></i></a>
        </div>
        <div class="bui-bar-main">弹出登录页</div>
        <div class="bui-bar-right">
            <!-- 右边按钮 -->
        </div>
       </div>
    </header>
    <main>
        <ul class="bui-list">
            <li class="bui-btn bui-box clearactive">
                <label class="bui-label">帐号</label>
                <div class="span1">
                    <input type="text" class="bui-input" value="" placeholder="请输入邮箱@qq.com" b-model="form.datas.username">
                </div>
            </li>
            <li class="bui-btn bui-box clearactive">
                <label class="bui-label">密码</label>
                <div class="span1">
                    <input type="password" class="bui-input" value="" placeholder="请输入密码" b-model="form.datas.password">
                </div>
            </li>
            <li class="bui-btn bui-box clearactive">
                <label class="bui-label">保存密码</label>
                <div class="span1">
                    <input type="checkbox" class="bui-checkbox" b-model="form.datas.save">
                </div>
            </li>
        </ul>
        <div class="container-y">
            <div class="bui-box-space">
                <div class="span1">
                    <div class="bui-btn round primary" b-click="form.submit">登录</div>
                </div>
            </div>
        </div>
    </main>
</div>
`;
		 },
							   loaded:function(requires, exports, module, global){

    const bs = bui.store({
        el: `#loginpart`,    // 容器下的行为指令
        scope: "form",      // 容器下的相同作用域指令
        data: {
            datas: {
                username:"",    // 账号名
                password:"",    // 密码
                save: false,     //保存密码
            },
        },
        methods: {
            checkForm(datas){

                for(let key in datas ){
                    let item = datas[key];
                    if( item === ""){
                        bui.hint(`${key}的内容不能为空`)
                        return false;
                    }
                }
                return true;
            },
            savePassword(val){

                if(this.$data.datas.save){
                    global.storage.set("userinfo",val);
                }else{
                    global.storage.remove("userinfo");
                }
            },
            close(){

                var dialog = bui.history.getPageDialog(module.id);

                dialog.close();
                
            },
            submit(){

                let canSumit = this.checkForm(this.datas);
                if( !canSumit ){
                    return;
                }

                bui.ajax({
                    url: global.apiurl + "json/token.json",
                    data: this.datas // 表单收集到的内容
                }).then((res)=>{
                    bui.hint("登录成功")

                    this.savePassword(this.$data.datas);

                    this.close();

                    let lastHistory = bui.history.getLast("exports");
                    lastHistory.refresh();
                })
            },
        },
        templates: {},
        mounted: function(){

            let uinfo = global.storage.get("userinfo",0);

            typeof uinfo ==="object" &&( this.datas = uinfo);
        }
    })

    return bs;
}});;loader.set("pages/main/cart",{
							   template:function(){
					   return ``;
		 },
							   loaded:function(require, exports, module, global){


    let data = [];

    return {
        data: data,
        add(opt){

            data.push(opt);

            console.log(data)
        },
        remove(id){

            bui.array.delete(data,id,"id");
        }
    }
}});;loader.set("pages/main/main",{
							   template:function(){
					   return `<!-- 这里还是一个标准的BUI页面 -->
<div class="bui-page bui-box-vertical">
    <header>
        <div class="bui-bar">
            <div class="bui-bar-left">
                <!-- 左边有图标示例 -->
                <div class="bui-btn btn-back"><i class="icon-back"></i></div>
            </div>
            <div class="bui-bar-main">BUI单页开发工程模板</div>
            <div class="bui-bar-right">
                <!-- 右边有图标示例 -->
                <div class="bui-btn" b-click="list.login"><i class="icon-info"></i></div>
            </div>
        </div>
    </header>
    <main>
        <component id="slide" name="pages/components/slide/slide" height="300" delay="true"></component>

        <!-- 中间内容 -->
        <ul class="bui-list" b-template="list.tplList(list.datas)">
            <!-- 
                <li class="bui-btn bui-box">
                    <div class="thumbnail"><img src="images/applogo.png"></div>
                    <div class="span1">文本</div>
                    <i class="icon-listright"></i>
                </li> 
            -->
        </ul>
    </main>
    <footer>
        <!-- 底部内容 -->
    </footer>
</div>`;
		 },
							   loaded:function(requires, exports, module, global){
    global.ajax({
        url: global.apiurl + "json/slide.json",
    }).then(function(result){
        let data = result.data.map(function(item,index){
            return {image: "http://easybui.com/demo/"+item.image }
        })

        loader.delay({
            id:"#slide",
            param: {
                height: 300,
                data: data
            }
        })

    })
    var loginPage = null;
    const bs = bui.store({
        el: `#${module.id}`,
        scope: "list",
        data: {
           datas: [],
        },
        mounted: function(){
            this.getList({
                url:`${module.path}main.json`,
                data: {}
            })
        },
        methods: {
            login(){
                if( loginPage ){
                    loginPage.open();
                    return;
                }
                loginPage = bui.page({
                    url:"pages/login/page.html",
                    param: {}
                })                
            },
            refresh(){
                this.datas.push({
                    "id":"bui4",
                    "title":"文章标题4",
                    "image":"images/applogo.png",
                    "desc":"文章的内容简介"
                })
            },
            getList(opt){
                bui.ajax(opt).then((result)=>{
                    this.datas = result.data;

                },function(result,status){
                });
            }
        },
        watch: {},
        computed: {},
        templates: {
            tplList:function(data){
                let html = "";
                data.forEach(item => {
                    html +=`<li class="bui-btn bui-box" href="pages/article/article.html?id=${item.id}">
                            <div class="thumbnail"><img src="${item.image}"></div>
                            <div class="span1">${item.title}</div>
                            <i class="icon-listright"></i>
                        </li>`
                });

                return html;
            }
        }
    })

    return bs;
}});;loader.set("pages/register/index",{
							   template:function(){
					   return `<div id="formpage" class="bui-page bui-box-vertical">
    <header>
       <div class="bui-bar">
        <div class="bui-bar-left">
            <a class="bui-btn" onclick="bui.back();"><i class="icon-back"></i></a>
        </div>
        <div class="bui-bar-main">注册页</div>
        <div class="bui-bar-right">
            <!-- 右边按钮 -->
        </div>
       </div>
    </header>
    <main>
        <ul class="bui-list">
            <li class="bui-btn bui-box clearactive">
                <label class="bui-label">帐号</label>
                <div class="span1">
                    <input type="text" class="bui-input" value="" placeholder="请输入邮箱@qq.com" b-model="form.datas.username" b-blur="form.checkRule($this,'username')" rule="/.+@qq.com/gim" tip="正确格式为：xxx@qq.com">
                </div>
            </li>
            <li class="bui-btn bui-box clearactive">
                <label class="bui-label">密码</label>
                <div class="span1">
                    <input type="password" class="bui-input" value="" placeholder="请输入密码" b-model="form.datas.password">
                </div>
            </li>
            <li class="bui-btn bui-box clearactive">
                <label class="bui-label">确认密码</label>
                <div class="span1">
                    <input type="password" class="bui-input" value="" placeholder="请再次输入密码" b-model="form.datas.comfirmpassword">
                </div>
            </li>
            <li class="bui-btn bui-box clearactive">
                <label class="bui-label">性别</label>
                <div class="span1">
                    <label><input type="radio" class="bui-radio" value="woman" b-model="form.datas.sex">女</label>
                    <label><input type="radio" class="bui-radio" value="man" b-model="form.datas.sex">男</label>
                </div>
            </li>
        </ul>
    </main>
    <footer>
        <div class="container-y">
            <div class="bui-box-space">
                <div class="span1">
                    <div class="bui-btn round" b-click="form.reset">重置</div>
                </div>
                <div class="span1">
                    <div class="bui-btn round primary" b-click="form.submit">提交</div>
                </div>
            </div>
        </div>
    </footer>
</div>
`;
		 },
							   loaded:function(requires, exports, module, global){

    const bs = bui.store({
        el: `#formpage`,    // 容器下的行为指令
        scope: "form",      // 容器下的相同作用域指令
        data: {
            datas: {
                username:"",    // 账号名
                password:"",    // 密码
                comfirmpassword:"",//确认密码
                sex:"woman",         //性别
            }
        },
        methods: {
            regexFromString(string) {

                var match = /^\/(.*)\/([a-z]*)$/.exec(string) 
             
                return new RegExp(match[1], match[2])
            },
            checkRule(dom,keyname){

                let rule = dom.getAttribute("rule");

                let tip = dom.getAttribute("tip");

                let regexp = this.regexFromString(rule);

                let val = dom.value;

                if( val && !regexp.test(val) ){



                    bui.hint(tip)
                    return false;
                }
            },
            checkForm(datas){

                for(let key in datas ){
                    let item = datas[key];
                    if( item === ""){
                        bui.hint(`${key}的内容不能为空`)
                        return false;
                    }
                }
                if( datas["password"] !== datas["comfirmpassword"]){
                    bui.hint(`两次密码不一致，请检查后提交`)
                }
                return true;
            },
            submit(){

                let canSumit = this.checkForm(this.datas);
                if( !canSumit ){
                    return;
                }

                bui.ajax({
                    url: global.apiurl + "json/token.json",
                    data: this.datas // 表单收集到的内容
                }).then((res)=>{
                    bui.hint("提交成功")
                })
            },
            reset(){
                this.datas = {
                    username:"",    // 账号名
                    password:"",    // 密码
                    comfirmpassword:"",//确认密码
                    sex:"",         //性别
                }
                bui.hint("重置成功");
            }
        },
        templates: {},
        mounted: function(){

        }
    })

    return bs;
}});